﻿-- HF10-126 - Add missing user-defined table types to the separated DB
IF NOT EXISTS (SELECT 1 FROM sys.table_types WHERE name = 'Type_CMS_GuidTable')
BEGIN
	CREATE TYPE [Type_CMS_GuidTable] AS TABLE(
		[Value] [UNIQUEIDENTIFIER] NULL
	)
END

IF NOT EXISTS (SELECT 1 FROM sys.table_types WHERE name = 'Type_CMS_BigIntTable')
BEGIN
	CREATE TYPE [Type_CMS_BigIntTable] AS TABLE(
		[Value] [bigint] NULL
	)
END

IF NOT EXISTS (SELECT 1 FROM sys.table_types WHERE name = 'Type_CMS_StringTable')
BEGIN
	CREATE TYPE [Type_CMS_StringTable] AS TABLE(
		[Value] [nvarchar](450) NULL
	)
END

GO
